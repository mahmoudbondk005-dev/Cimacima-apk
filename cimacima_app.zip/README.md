# تطبيق سيما سيما (Flutter)

يقرأ من نفس جدول `movies` في Supabase بتاع الموقع.

## التشغيل
```
flutter create . --org online.cimacima --project-name cimacima   # يولّد مجلدي android/ و ios/
flutter pub get
flutter run
```

## أندرويد
- أضف في `android/app/src/main/AndroidManifest.xml` داخل `<manifest>`:
  `<uses-permission android:name="android.permission.INTERNET"/>`
- وفي `<application>` أضف `android:usesCleartextTraffic="true"` لو فيه روابط http.
- `minSdkVersion` لازم 21 أو أعلى.

## الملفات
- `lib/config.dart` إعدادات Supabase والألوان
- `lib/models.dart` تحويل صفوف الجدول (الحلقات، المواسم، السيرفرات، التحميل)
- `lib/api.dart` جلب المحتوى وعدّاد المشاهدات
- `lib/screens.dart` الرئيسية، البحث، المفضلة، التفاصيل، المشغّل

## بناء الـ APK من الموبايل (GitHub Actions)
1. ارفع كل ملفات المشروع (بما فيها مجلد `.github`) على مستودع GitHub.
2. افتح تبويب **Actions** ← **Build APK** ← **Run workflow**.
3. بعد ما يخلص (5-10 دقايق) افتح التشغيل ونزّل الملف من **Artifacts** (`cimacima-apk`).
4. فك الـ zip وثبّت `app-release.apk`.
