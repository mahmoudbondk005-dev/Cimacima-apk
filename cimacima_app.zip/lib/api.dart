import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'models.dart';

final _headers = {'apikey': supabaseKey, 'Authorization': 'Bearer $supabaseKey'};

Future<List<Item>> fetchItems() async {
  final res = await http.get(
    Uri.parse('$supabaseUrl/rest/v1/movies?select=*&limit=2000'),
    headers: _headers,
  );
  if (res.statusCode != 200) throw Exception('تعذر تحميل المحتوى (${res.statusCode})');
  final rows = (jsonDecode(utf8.decode(res.bodyBytes)) as List).cast<Map<String, dynamic>>();
  final items = rows.map(Item.fromRow).toList()..sort((a, b) => b.id.compareTo(a.id));
  return items;
}

Future<void> countView(int id) async {
  try {
    await http.post(
      Uri.parse('$supabaseUrl/rest/v1/rpc/increment_views'),
      headers: {..._headers, 'Content-Type': 'application/json'},
      body: jsonEncode({'movie_id': id}),
    );
  } catch (_) {}
}
