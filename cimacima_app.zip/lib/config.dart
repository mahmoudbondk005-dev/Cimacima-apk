// نفس بيانات الموقع (المفتاح publishable مخصص للقراءة العامة ومحمي بـ RLS)
const supabaseUrl = 'https://axvibvssjizkrfdqlyow.supabase.co';
const supabaseKey = 'sb_publishable_72qMAroeSPFAMXfL2AoVQA_5RnDslsh';
const appName = 'سيما سيما';
const gold = 0xFFFFB000;
const categories = ['أفلام عربي', 'أفلام أجنبي', 'مسلسلات عربي', 'مسلسلات أجنبي'];
