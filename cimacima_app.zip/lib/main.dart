import 'package:flutter/material.dart';
import 'api.dart';
import 'config.dart';
import 'models.dart';
import 'store.dart';
import 'screens.dart';

final favorites = Favorites();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await favorites.load();
  runApp(const CimaApp());
}

class CimaApp extends StatelessWidget {
  const CimaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: appName,
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          scaffoldBackgroundColor: const Color(0xFF0B0F17),
          colorScheme: const ColorScheme.dark(primary: Color(gold)),
          appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF0B0F17)),
        ),
        builder: (c, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;
  late Future<List<Item>> future = fetchItems();

  void reload() => setState(() => future = fetchItems());

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Item>>(
      future: future,
      builder: (context, snap) {
        Widget body;
        if (snap.connectionState != ConnectionState.done) {
          body = const Center(child: CircularProgressIndicator());
        } else if (snap.hasError) {
          body = Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('تعذر تحميل المحتوى'),
            const SizedBox(height: 12),
            FilledButton(onPressed: reload, child: const Text('إعادة المحاولة')),
          ]));
        } else {
          final items = snap.data!;
          body = [
            HomeScreen(items: items),
            SearchScreen(items: items),
            FavoritesScreen(items: items),
          ][tab];
        }
        return Scaffold(
          appBar: AppBar(
            title: const Text(appName, style: TextStyle(color: Color(gold), fontWeight: FontWeight.w900)),
            centerTitle: true,
          ),
          body: body,
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
              NavigationDestination(icon: Icon(Icons.search), label: 'بحث'),
              NavigationDestination(icon: Icon(Icons.favorite_border), label: 'المفضلة'),
            ],
          ),
        );
      },
    );
  }
}
