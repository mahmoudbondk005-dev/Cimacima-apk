import 'dart:convert';

dynamic _decode(dynamic v) {
  if (v is String && v.trim().isNotEmpty) {
    try {
      return jsonDecode(v);
    } catch (_) {
      return null;
    }
  }
  return v;
}

class Link {
  final String name, url;
  Link(this.name, this.url);
}

class Episode {
  final String title, url;
  Episode(this.title, this.url);
}

class Season {
  final String name;
  final List<Episode> episodes;
  Season(this.name, this.episodes);
}

List<Episode> _eps(dynamic list) {
  if (list is! List) return [];
  var i = 0;
  return list.whereType<Map>().map((e) {
    i++;
    final t = (e['title'] ?? e['name'] ?? 'الحلقة $i').toString();
    final u = (e['url'] ?? e['movie_url'] ?? '').toString();
    return Episode(t, u);
  }).where((e) => e.url.isNotEmpty).toList();
}

String normalizeCategory(String? cat) {
  final c = (cat ?? '').trim();
  if (c == 'فيلم' || c == 'دراما') return 'أفلام عربي';
  if (c == 'مسلسل') return 'مسلسلات عربي';
  const known = ['أفلام عربي', 'أفلام أجنبي', 'مسلسلات عربي', 'مسلسلات أجنبي'];
  if (known.contains(c)) return c;
  if (RegExp(r'^(مسلسل|مسلسلات)(\s|$)').hasMatch(c)) {
    return RegExp(r'(ترك|كور|هند|صين|يابان|آسيو|اسيو|اجنب|أجنب|أنمي|انمي)').hasMatch(c)
        ? 'مسلسلات أجنبي'
        : 'مسلسلات عربي';
  }
  return 'أفلام عربي';
}

class Item {
  final int id;
  final String title, category, year, rating, poster, desc, duration;
  final int views;
  final List<Link> servers, downloads;
  final List<Episode> episodes;
  final List<Season> seasons;

  Item({
    required this.id,
    required this.title,
    required this.category,
    required this.year,
    required this.rating,
    required this.poster,
    required this.desc,
    required this.duration,
    required this.views,
    required this.servers,
    required this.downloads,
    required this.episodes,
    required this.seasons,
  });

  bool get isSeries => category.startsWith('مسلسل');

  factory Item.fromRow(Map<String, dynamic> r) {
    final epsRaw = _decode(r['episodes']);
    final list = epsRaw is List ? epsRaw : [];
    final plain = list.where((x) =>
        x is Map && x['__cimaOverlay'] == null && x['__cimaSeasons'] == null && x['__cimaMeta'] == null);
    final sMap = list.whereType<Map>().firstWhere((x) => x['__cimaSeasons'] == true,
        orElse: () => {});
    final seasons = <Season>[];
    if (sMap.isNotEmpty && sMap['enabled'] != false && sMap['seasons'] is List) {
      var n = 0;
      for (final s in (sMap['seasons'] as List).whereType<Map>()) {
        n++;
        seasons.add(Season((s['name'] ?? s['title'] ?? 'الموسم $n').toString(), _eps(s['episodes'])));
      }
    }
    List<Link> links(dynamic v, {bool single = false}) {
      final d = _decode(v);
      if (d is List) {
        return d.whereType<Map>().where((x) => (x['url'] ?? '').toString().isNotEmpty)
            .map((x) => Link((x['name'] ?? 'سيرفر').toString(), x['url'].toString())).toList();
      }
      if (single && v is String && v.startsWith('http')) return [Link('السيرفر الأساسي', v)];
      return [];
    }

    final poster = (r['poster_url'] ?? '').toString();
    return Item(
      id: (r['Id'] ?? r['id'] ?? 0) as int,
      title: (r['title'] ?? '').toString(),
      category: normalizeCategory(r['category']?.toString()),
      year: (r['year'] ?? '').toString(),
      rating: (r['rating'] ?? '').toString(),
      poster: poster.contains('via.placeholder.com') ? '' : poster,
      desc: (r['description'] ?? '').toString(),
      duration: (r['duration'] ?? '').toString() == '—' ? '' : (r['duration'] ?? '').toString(),
      views: int.tryParse((r['views'] ?? 0).toString()) ?? 0,
      servers: links(r['movie_url'], single: true),
      downloads: links(r['download_links']),
      episodes: _eps(plain.toList()),
      seasons: seasons,
    );
  }
}
