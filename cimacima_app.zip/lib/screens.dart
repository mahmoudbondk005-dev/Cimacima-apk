import 'package:cached_network_image/cached_network_image.dart';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'api.dart';
import 'config.dart';
import 'main.dart' show favorites;
import 'models.dart';

/// ---------- بطاقة العمل ----------
class PosterCard extends StatelessWidget {
  final Item item;
  const PosterCard(this.item, {super.key});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailsScreen(item))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: item.poster.isEmpty
                  ? Container(color: const Color(0xFF1A1F2A), child: const Center(child: Icon(Icons.movie)))
                  : CachedNetworkImage(
                      imageUrl: item.poster, fit: BoxFit.cover, width: double.infinity,
                      errorWidget: (_, __, ___) => Container(color: const Color(0xFF1A1F2A))),
            ),
          ),
          const SizedBox(height: 6),
          Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
          Text('${item.year}  ${item.rating.isEmpty ? '' : '★ ${item.rating}'}',
              style: const TextStyle(fontSize: 11, color: Colors.white54)),
        ]),
      );
}

/// ---------- الرئيسية ----------
class HomeScreen extends StatelessWidget {
  final List<Item> items;
  const HomeScreen({super.key, required this.items});

  Widget row(String title, List<Item> list) {
    if (list.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
          child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Color(gold)))),
      SizedBox(
        height: 220,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: list.length > 30 ? 30 : list.length,
          separatorBuilder: (_, __) => const SizedBox(width: 12),
          itemBuilder: (_, i) => SizedBox(width: 130, child: PosterCard(list[i])),
        ),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final top = [...items]..sort((a, b) => b.views.compareTo(a.views));
    return ListView(children: [
      row('الأكثر مشاهدة', top.take(15).toList()),
      for (final c in categories) row(c, items.where((e) => e.category == c).toList()),
      const SizedBox(height: 20),
    ]);
  }
}

/// ---------- البحث ----------
class SearchScreen extends StatefulWidget {
  final List<Item> items;
  const SearchScreen({super.key, required this.items});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String q = '';
  @override
  Widget build(BuildContext context) {
    final res = q.trim().isEmpty
        ? <Item>[]
        : widget.items.where((e) => e.title.toLowerCase().contains(q.trim().toLowerCase())).toList();
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: TextField(
          onChanged: (v) => setState(() => q = v),
          decoration: InputDecoration(
              hintText: 'ابحث عن فيلم أو مسلسل...',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)),
        ),
      ),
      Expanded(child: PosterGrid(res)),
    ]);
  }
}

class PosterGrid extends StatelessWidget {
  final List<Item> list;
  const PosterGrid(this.list, {super.key});
  @override
  Widget build(BuildContext context) => GridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 140, childAspectRatio: 0.58, crossAxisSpacing: 10, mainAxisSpacing: 10),
        itemCount: list.length,
        itemBuilder: (_, i) => PosterCard(list[i]),
      );
}

/// ---------- المفضلة ----------
class FavoritesScreen extends StatelessWidget {
  final List<Item> items;
  const FavoritesScreen({super.key, required this.items});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: favorites,
        builder: (_, __) {
          final list = items.where((e) => favorites.ids.contains(e.id)).toList();
          if (list.isEmpty) return const Center(child: Text('مفيش مفضلة لسه'));
          return PosterGrid(list);
        },
      );
}

/// ---------- التفاصيل ----------
class DetailsScreen extends StatefulWidget {
  final Item item;
  const DetailsScreen(this.item, {super.key});
  @override
  State<DetailsScreen> createState() => _DetailsScreenState();
}

class _DetailsScreenState extends State<DetailsScreen> {
  int season = 0;

  void play(String title, List<Link> servers) {
    if (servers.isEmpty) return;
    countView(widget.item.id);
    Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerScreen(title: title, servers: servers)));
  }

  @override
  Widget build(BuildContext context) {
    final it = widget.item;
    final eps = it.seasons.isNotEmpty ? it.seasons[season].episodes : it.episodes;
    return Scaffold(
      appBar: AppBar(title: Text(it.title, maxLines: 1, overflow: TextOverflow.ellipsis), actions: [
        ListenableBuilder(
            listenable: favorites,
            builder: (_, __) => IconButton(
                  icon: Icon(favorites.ids.contains(it.id) ? Icons.favorite : Icons.favorite_border,
                      color: const Color(gold)),
                  onPressed: () => favorites.toggle(it.id),
                )),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: it.poster.isEmpty
                ? Container(width: 120, height: 180, color: const Color(0xFF1A1F2A))
                : CachedNetworkImage(imageUrl: it.poster, width: 120, height: 180, fit: BoxFit.cover),
          ),
          const SizedBox(width: 14),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(it.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text([it.year, it.duration, if (it.rating.isNotEmpty) '★ ${it.rating}'].where((e) => e.isNotEmpty).join('  •  '),
                style: const TextStyle(color: Colors.white60)),
            const SizedBox(height: 4),
            Text(it.category, style: const TextStyle(color: Color(gold))),
          ])),
        ]),
        const SizedBox(height: 16),
        if (!it.isSeries || eps.isEmpty)
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: const Color(gold), foregroundColor: Colors.black),
            onPressed: it.servers.isEmpty ? null : () => play(it.title, it.servers),
            icon: const Icon(Icons.play_arrow),
            label: const Text('شاهد الآن'),
          ),
        if (it.desc.isNotEmpty) ...[
          const SizedBox(height: 16),
          Text(it.desc, style: const TextStyle(height: 1.6, color: Colors.white70)),
        ],
        if (it.isSeries && it.seasons.length > 1) ...[
          const SizedBox(height: 16),
          SizedBox(
            height: 40,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: it.seasons.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) => ChoiceChip(
                  label: Text(it.seasons[i].name),
                  selected: season == i,
                  onSelected: (_) => setState(() => season = i)),
            ),
          ),
        ],
        if (it.isSeries && eps.isNotEmpty) ...[
          const SizedBox(height: 16),
          const Text('الحلقات', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Color(gold))),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final e in eps)
              ActionChip(
                  label: Text(e.title),
                  onPressed: () => play('${it.title} - ${e.title}', [Link('السيرفر', e.url)])),
          ]),
        ],
      ]),
    );
  }
}

/// ---------- المشغّل ----------
class PlayerScreen extends StatefulWidget {
  final String title;
  final List<Link> servers;
  const PlayerScreen({super.key, required this.title, required this.servers});
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  int idx = 0;
  VideoPlayerController? vc;
  ChewieController? cc;
  WebViewController? wv;

  bool _isDirect(String u) {
    final p = Uri.tryParse(u)?.path.toLowerCase() ?? '';
    return p.endsWith('.m3u8') || p.endsWith('.mp4') || p.endsWith('.mkv') || p.endsWith('.webm');
  }

  Future<void> _load() async {
    cc?.dispose();
    await vc?.dispose();
    cc = null; vc = null; wv = null;
    final url = widget.servers[idx].url;
    if (_isDirect(url)) {
      vc = VideoPlayerController.networkUrl(Uri.parse(url));
      await vc!.initialize();
      cc = ChewieController(videoPlayerController: vc!, autoPlay: true, allowFullScreen: true);
    } else {
      wv = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..loadRequest(Uri.parse(url));
    }
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    cc?.dispose();
    vc?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
        body: Column(children: [
          AspectRatio(
            aspectRatio: 16 / 9,
            child: cc != null
                ? Chewie(controller: cc!)
                : wv != null
                    ? WebViewWidget(controller: wv!)
                    : const Center(child: CircularProgressIndicator()),
          ),
          if (widget.servers.length > 1)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Wrap(spacing: 8, children: [
                for (var i = 0; i < widget.servers.length; i++)
                  ChoiceChip(
                      label: Text(widget.servers[i].name),
                      selected: idx == i,
                      onSelected: (_) { idx = i; _load(); }),
              ]),
            ),
        ]),
      );
}
