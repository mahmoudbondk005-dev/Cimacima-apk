import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Favorites extends ChangeNotifier {
  static const _k = 'cima_favorites';
  final Set<int> ids = {};

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    ids..clear()..addAll((p.getStringList(_k) ?? []).map(int.parse));
    notifyListeners();
  }

  Future<void> toggle(int id) async {
    ids.contains(id) ? ids.remove(id) : ids.add(id);
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_k, ids.map((e) => e.toString()).toList());
    notifyListeners();
  }
}
